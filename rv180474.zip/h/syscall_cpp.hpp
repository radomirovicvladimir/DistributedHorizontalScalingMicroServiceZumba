#ifndef _syscall_cpp
#define _syscall_cpp

#include "syscall_c.h"

void* operator new(size_t);
void  operator delete(void*) noexcept;

class Thread {
public:
    Thread(void (*body)(void*), void* arg);
    virtual ~Thread();
    int start();
    static void dispatch();
    static int sleep(time_t);
protected:
    Thread();
    virtual void run() {}
private:
    thread_t myHandle;
    void (*body)(void*);
    void* arg;

    // --- non-interface-affecting internals (do NOT touch layout / vtable) ---
    // Trampoline used when the protected default ctor is invoked so that a
    // derived class's virtual run() gets called. body/arg fields above are
    // seeded with `(&run_trampoline, this)`. This is a private static (not a
    // member function) so it doesn't participate in the vtable — PDF layout
    // constraints stay intact.
    static void run_trampoline(void* self_v);
};

class Semaphore {
public:
    Semaphore(unsigned init = 1);
    virtual ~Semaphore();
    int wait();
    int signal();
private:
    sem_t myHandle;
};

class PeriodicThread : public Thread {
public:
    void terminate();
protected:
    PeriodicThread(time_t period);
    virtual void periodicActivation() {}
private:
    time_t period;
};

class Console {
public:
    static char getc();
    static void putc(char);
};

#endif
